import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
import pickle
import os
import warnings
from random import choice, shuffle

warnings.filterwarnings("ignore")

DATA_PATH = "mental_health_phrases.csv"
MODEL_PATH = "mh_model.pkl"
VEC_PATH = "vectorizer.pkl"

# Load CSV
def load_dataset():
    df = pd.read_csv(DATA_PATH)
    return df

# Simple augmentation to improve small dataset
def augment_text(text):
    text = text.replace("feel", choice(["am", "feel", "seem"]))
    text = text.replace("today", choice(["this morning", "this evening", "now"]))
    text = text.replace("I am", choice(["I'm", "I feel", "I"]))
    return text

def augment_dataset(df):
    augmented_data = []
    for _, row in df.iterrows():
        augmented_data.append((row["text"], row["label"]))
        for _ in range(3):  
            augmented_data.append((augment_text(row["text"]), row["label"]))
    shuffle(augmented_data)
    return pd.DataFrame(augmented_data, columns=["text", "label"])

# Train and save model
def train_and_save_model():
    print("Training model...")
    df = load_dataset()
    df = augment_dataset(df) 

    X = df["text"]
    y = df["label"]

    vectorizer = TfidfVectorizer(ngram_range=(1,2))
    X_vec = vectorizer.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(
        X_vec, y, test_size=0.2, random_state=42
    )

    model = LogisticRegression(max_iter=500, class_weight="balanced")
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    print("\nTraining complete!")
    print("Accuracy:", accuracy_score(y_test, y_pred))
    print(classification_report(y_test, y_pred, zero_division=0))

    # Save model & vectorizer
    with open(MODEL_PATH, "wb") as f:
        pickle.dump(model, f)
    with open(VEC_PATH, "wb") as f:
        pickle.dump(vectorizer, f)

    return model, vectorizer

# Load existing model if exists
def load_model():
    if os.path.exists(MODEL_PATH) and os.path.exists(VEC_PATH):
        with open(MODEL_PATH, "rb") as f:
            model = pickle.load(f)
        with open(VEC_PATH, "rb") as f:
            vectorizer = pickle.load(f)
        print("Loaded saved model.\n")
        return model, vectorizer
    else:
        return train_and_save_model()

# Optional rule-based fallback for low confidence
def fallback_rules(text):
    text_lower = text.lower()
    if any(word in text_lower for word in ["anxious", "nervous", "worried", "scared"]):
        return "anxiety"
    elif any(word in text_lower for word in ["stress", "overwhelming", "pressure"]):
        return "stress"
    elif any(word in text_lower for word in ["motivated", "excited", "inspired", "energetic"]):
        return "motivation"
    else:
        return "neutral"

# Main interactive loop
def main():
    print("Mental Health Phrase Classifier\n")
    model, vectorizer = load_model()

    while True:
        text = input("Enter phrase ('exit' to quit'): ")
        if text.lower() == "exit":
            break

        text_vec = vectorizer.transform([text])
        prediction = model.predict(text_vec)[0]
        confidence = max(model.predict_proba(text_vec)[0])

        if confidence < 0.5:
            prediction = fallback_rules(text)

        print(f"Predicted Category: {prediction} (Confidence: {confidence:.2f})\n")

if __name__ == "__main__":
    main()
